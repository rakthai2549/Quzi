﻿namespace Quzi_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            groupBox1 = new GroupBox();
            label4 = new Label();
            label3 = new Label();
            maskedTextBox25 = new MaskedTextBox();
            maskedTextBox26 = new MaskedTextBox();
            maskedTextBox23 = new MaskedTextBox();
            maskedTextBox24 = new MaskedTextBox();
            maskedTextBox21 = new MaskedTextBox();
            maskedTextBox22 = new MaskedTextBox();
            maskedTextBox19 = new MaskedTextBox();
            label16 = new Label();
            maskedTextBox20 = new MaskedTextBox();
            label17 = new Label();
            label14 = new Label();
            label15 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox3 = new GroupBox();
            maskedTextBox10 = new MaskedTextBox();
            maskedTextBox9 = new MaskedTextBox();
            maskedTextBox8 = new MaskedTextBox();
            maskedTextBox7 = new MaskedTextBox();
            maskedTextBox6 = new MaskedTextBox();
            maskedTextBox5 = new MaskedTextBox();
            maskedTextBox4 = new MaskedTextBox();
            maskedTextBox3 = new MaskedTextBox();
            maskedTextBox2 = new MaskedTextBox();
            maskedTextBox1 = new MaskedTextBox();
            label23 = new Label();
            label22 = new Label();
            label11 = new Label();
            label13 = new Label();
            label12 = new Label();
            label10 = new Label();
            label9 = new Label();
            groupBox2 = new GroupBox();
            label18 = new Label();
            maskedTextBox16 = new MaskedTextBox();
            maskedTextBox15 = new MaskedTextBox();
            maskedTextBox14 = new MaskedTextBox();
            maskedTextBox13 = new MaskedTextBox();
            maskedTextBox12 = new MaskedTextBox();
            maskedTextBox11 = new MaskedTextBox();
            label21 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label8 = new Label();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(80, 71);
            button1.Name = "button1";
            button1.Size = new Size(144, 65);
            button1.TabIndex = 0;
            button1.Text = "อาจารย์ แดง";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(80, 202);
            button2.Name = "button2";
            button2.Size = new Size(144, 65);
            button2.TabIndex = 1;
            button2.Text = "อาจารย์ที่ปรึกษา แจ็ค";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(80, 354);
            button3.Name = "button3";
            button3.Size = new Size(144, 65);
            button3.TabIndex = 2;
            button3.Text = "รวม";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(maskedTextBox25);
            groupBox1.Controls.Add(maskedTextBox26);
            groupBox1.Controls.Add(maskedTextBox23);
            groupBox1.Controls.Add(maskedTextBox24);
            groupBox1.Controls.Add(maskedTextBox21);
            groupBox1.Controls.Add(maskedTextBox22);
            groupBox1.Controls.Add(maskedTextBox19);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(maskedTextBox20);
            groupBox1.Controls.Add(label17);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(275, 50);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(872, 125);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(471, 76);
            label4.Name = "label4";
            label4.Size = new Size(40, 20);
            label4.TabIndex = 53;
            label4.Text = "สาขา";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 78);
            label3.Name = "label3";
            label3.Size = new Size(81, 20);
            label3.TabIndex = 52;
            label3.Text = "ชื่อ-นามสกุล";
            // 
            // maskedTextBox25
            // 
            maskedTextBox25.Location = new Point(110, 75);
            maskedTextBox25.Name = "maskedTextBox25";
            maskedTextBox25.Size = new Size(125, 27);
            maskedTextBox25.TabIndex = 51;
            // 
            // maskedTextBox26
            // 
            maskedTextBox26.Location = new Point(110, 29);
            maskedTextBox26.Name = "maskedTextBox26";
            maskedTextBox26.Size = new Size(125, 27);
            maskedTextBox26.TabIndex = 50;
            // 
            // maskedTextBox23
            // 
            maskedTextBox23.Location = new Point(330, 76);
            maskedTextBox23.Name = "maskedTextBox23";
            maskedTextBox23.Size = new Size(125, 27);
            maskedTextBox23.TabIndex = 49;
            // 
            // maskedTextBox24
            // 
            maskedTextBox24.Location = new Point(330, 30);
            maskedTextBox24.Name = "maskedTextBox24";
            maskedTextBox24.Size = new Size(125, 27);
            maskedTextBox24.TabIndex = 48;
            // 
            // maskedTextBox21
            // 
            maskedTextBox21.Location = new Point(527, 76);
            maskedTextBox21.Name = "maskedTextBox21";
            maskedTextBox21.Size = new Size(125, 27);
            maskedTextBox21.TabIndex = 47;
            // 
            // maskedTextBox22
            // 
            maskedTextBox22.Location = new Point(527, 30);
            maskedTextBox22.Name = "maskedTextBox22";
            maskedTextBox22.Size = new Size(125, 27);
            maskedTextBox22.TabIndex = 46;
            // 
            // maskedTextBox19
            // 
            maskedTextBox19.Location = new Point(730, 79);
            maskedTextBox19.Name = "maskedTextBox19";
            maskedTextBox19.Size = new Size(125, 27);
            maskedTextBox19.TabIndex = 45;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(658, 71);
            label16.Name = "label16";
            label16.Size = new Size(59, 20);
            label16.TabIndex = 18;
            label16.Text = "ที่ปรึกษา";
            // 
            // maskedTextBox20
            // 
            maskedTextBox20.Location = new Point(730, 33);
            maskedTextBox20.Name = "maskedTextBox20";
            maskedTextBox20.Size = new Size(125, 27);
            maskedTextBox20.TabIndex = 44;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(658, 33);
            label17.Name = "label17";
            label17.Size = new Size(59, 20);
            label17.TabIndex = 14;
            label17.Text = "ที่ปรึกษา";
            label17.Click += label17_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(240, 74);
            label14.Name = "label14";
            label14.Size = new Size(84, 20);
            label14.TabIndex = 13;
            label14.Text = "รหัสนักศึกษา";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(240, 33);
            label15.Name = "label15";
            label15.Size = new Size(84, 20);
            label15.TabIndex = 12;
            label15.Text = "รหัสนักศึกษา";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(471, 29);
            label2.Name = "label2";
            label2.Size = new Size(40, 20);
            label2.TabIndex = 1;
            label2.Text = "สาขา";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 29);
            label1.Name = "label1";
            label1.Size = new Size(81, 20);
            label1.TabIndex = 0;
            label1.Text = "ชื่อ-นามสกุล";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(maskedTextBox10);
            groupBox3.Controls.Add(maskedTextBox9);
            groupBox3.Controls.Add(maskedTextBox8);
            groupBox3.Controls.Add(maskedTextBox7);
            groupBox3.Controls.Add(maskedTextBox6);
            groupBox3.Controls.Add(maskedTextBox5);
            groupBox3.Controls.Add(maskedTextBox4);
            groupBox3.Controls.Add(maskedTextBox3);
            groupBox3.Controls.Add(maskedTextBox2);
            groupBox3.Controls.Add(maskedTextBox1);
            groupBox3.Controls.Add(label23);
            groupBox3.Controls.Add(label22);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(label13);
            groupBox3.Controls.Add(label12);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(label9);
            groupBox3.Location = new Point(275, 331);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(872, 125);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "groupBox3";
            // 
            // maskedTextBox10
            // 
            maskedTextBox10.Location = new Point(703, 84);
            maskedTextBox10.Name = "maskedTextBox10";
            maskedTextBox10.Size = new Size(125, 27);
            maskedTextBox10.TabIndex = 35;
            // 
            // maskedTextBox9
            // 
            maskedTextBox9.Location = new Point(553, 84);
            maskedTextBox9.Name = "maskedTextBox9";
            maskedTextBox9.Size = new Size(125, 27);
            maskedTextBox9.TabIndex = 34;
            // 
            // maskedTextBox8
            // 
            maskedTextBox8.Location = new Point(404, 81);
            maskedTextBox8.Name = "maskedTextBox8";
            maskedTextBox8.Size = new Size(125, 27);
            maskedTextBox8.TabIndex = 33;
            // 
            // maskedTextBox7
            // 
            maskedTextBox7.Location = new Point(263, 81);
            maskedTextBox7.Name = "maskedTextBox7";
            maskedTextBox7.Size = new Size(125, 27);
            maskedTextBox7.TabIndex = 32;
            // 
            // maskedTextBox6
            // 
            maskedTextBox6.Location = new Point(110, 81);
            maskedTextBox6.Name = "maskedTextBox6";
            maskedTextBox6.Size = new Size(125, 27);
            maskedTextBox6.TabIndex = 31;
            // 
            // maskedTextBox5
            // 
            maskedTextBox5.Location = new Point(703, 38);
            maskedTextBox5.Name = "maskedTextBox5";
            maskedTextBox5.Size = new Size(125, 27);
            maskedTextBox5.TabIndex = 30;
            // 
            // maskedTextBox4
            // 
            maskedTextBox4.Location = new Point(553, 35);
            maskedTextBox4.Name = "maskedTextBox4";
            maskedTextBox4.Size = new Size(125, 27);
            maskedTextBox4.TabIndex = 29;
            // 
            // maskedTextBox3
            // 
            maskedTextBox3.Location = new Point(404, 35);
            maskedTextBox3.Name = "maskedTextBox3";
            maskedTextBox3.Size = new Size(125, 27);
            maskedTextBox3.TabIndex = 28;
            // 
            // maskedTextBox2
            // 
            maskedTextBox2.Location = new Point(263, 35);
            maskedTextBox2.Name = "maskedTextBox2";
            maskedTextBox2.Size = new Size(125, 27);
            maskedTextBox2.TabIndex = 27;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(110, 35);
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(125, 27);
            maskedTextBox1.TabIndex = 26;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(283, 8);
            label23.Name = "label23";
            label23.Size = new Size(81, 20);
            label23.TabIndex = 25;
            label23.Text = "ชื่อ-นามสกุล";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(426, 9);
            label22.Name = "label22";
            label22.Size = new Size(76, 20);
            label22.TabIndex = 22;
            label22.Text = "สาขาที่เรียน";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(136, 8);
            label11.Name = "label11";
            label11.Size = new Size(84, 20);
            label11.TabIndex = 11;
            label11.Text = "รหัสนักศึกษา";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(730, 9);
            label13.Name = "label13";
            label13.Size = new Size(37, 20);
            label13.TabIndex = 5;
            label13.Text = "เกรด";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(586, 8);
            label12.Name = "label12";
            label12.Size = new Size(48, 20);
            label12.TabIndex = 4;
            label12.Text = "คะแนน";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 84);
            label10.Name = "label10";
            label10.Size = new Size(87, 20);
            label10.TabIndex = 2;
            label10.Text = "คะแนนคนที่ 2";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 38);
            label9.Name = "label9";
            label9.Size = new Size(87, 20);
            label9.TabIndex = 1;
            label9.Text = "คะแนนคนที่ 1";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label18);
            groupBox2.Controls.Add(maskedTextBox16);
            groupBox2.Controls.Add(maskedTextBox15);
            groupBox2.Controls.Add(maskedTextBox14);
            groupBox2.Controls.Add(maskedTextBox13);
            groupBox2.Controls.Add(maskedTextBox12);
            groupBox2.Controls.Add(maskedTextBox11);
            groupBox2.Controls.Add(label21);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label8);
            groupBox2.Location = new Point(275, 181);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(872, 125);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Text = "groupBox2";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(471, 78);
            label18.Name = "label18";
            label18.Size = new Size(40, 20);
            label18.TabIndex = 42;
            label18.Text = "สาขา";
            // 
            // maskedTextBox16
            // 
            maskedTextBox16.Location = new Point(521, 75);
            maskedTextBox16.Name = "maskedTextBox16";
            maskedTextBox16.Size = new Size(125, 27);
            maskedTextBox16.TabIndex = 41;
            // 
            // maskedTextBox15
            // 
            maskedTextBox15.Location = new Point(517, 30);
            maskedTextBox15.Name = "maskedTextBox15";
            maskedTextBox15.Size = new Size(125, 27);
            maskedTextBox15.TabIndex = 40;
            // 
            // maskedTextBox14
            // 
            maskedTextBox14.Location = new Point(110, 75);
            maskedTextBox14.Name = "maskedTextBox14";
            maskedTextBox14.Size = new Size(125, 27);
            maskedTextBox14.TabIndex = 39;
            // 
            // maskedTextBox13
            // 
            maskedTextBox13.Location = new Point(109, 30);
            maskedTextBox13.Name = "maskedTextBox13";
            maskedTextBox13.Size = new Size(125, 27);
            maskedTextBox13.TabIndex = 38;
            // 
            // maskedTextBox12
            // 
            maskedTextBox12.Location = new Point(330, 75);
            maskedTextBox12.Name = "maskedTextBox12";
            maskedTextBox12.Size = new Size(125, 27);
            maskedTextBox12.TabIndex = 37;
            // 
            // maskedTextBox11
            // 
            maskedTextBox11.Location = new Point(330, 29);
            maskedTextBox11.Name = "maskedTextBox11";
            maskedTextBox11.Size = new Size(125, 27);
            maskedTextBox11.TabIndex = 36;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(471, 28);
            label21.Name = "label21";
            label21.Size = new Size(40, 20);
            label21.TabIndex = 21;
            label21.Text = "สาขา";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(16, 75);
            label7.Name = "label7";
            label7.Size = new Size(84, 20);
            label7.TabIndex = 10;
            label7.Text = "ชื่อขนามสกุล";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(240, 74);
            label6.Name = "label6";
            label6.Size = new Size(84, 20);
            label6.TabIndex = 9;
            label6.Text = "รหัสนักศึกษา";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(240, 33);
            label5.Name = "label5";
            label5.Size = new Size(84, 20);
            label5.TabIndex = 8;
            label5.Text = "รหัสนักศึกษา";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(16, 29);
            label8.Name = "label8";
            label8.Size = new Size(81, 20);
            label8.TabIndex = 0;
            label8.Text = "ชื่อ-นามสกุล";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1298, 498);
            Controls.Add(groupBox2);
            Controls.Add(groupBox3);
            Controls.Add(groupBox1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private GroupBox groupBox1;
        private GroupBox groupBox3;
        private Label label2;
        private Label label1;
        private Label label13;
        private Label label12;
        private Label label10;
        private Label label9;
        private GroupBox groupBox2;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label8;
        private Label label11;
        private Label label17;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label22;
        private Label label21;
        private Label label23;
        private MaskedTextBox maskedTextBox21;
        private MaskedTextBox maskedTextBox22;
        private MaskedTextBox maskedTextBox19;
        private MaskedTextBox maskedTextBox20;
        private MaskedTextBox maskedTextBox10;
        private MaskedTextBox maskedTextBox9;
        private MaskedTextBox maskedTextBox8;
        private MaskedTextBox maskedTextBox7;
        private MaskedTextBox maskedTextBox6;
        private MaskedTextBox maskedTextBox5;
        private MaskedTextBox maskedTextBox4;
        private MaskedTextBox maskedTextBox3;
        private MaskedTextBox maskedTextBox2;
        private MaskedTextBox maskedTextBox1;
        private MaskedTextBox maskedTextBox16;
        private MaskedTextBox maskedTextBox15;
        private MaskedTextBox maskedTextBox14;
        private MaskedTextBox maskedTextBox13;
        private MaskedTextBox maskedTextBox12;
        private MaskedTextBox maskedTextBox11;
        private MaskedTextBox maskedTextBox25;
        private MaskedTextBox maskedTextBox26;
        private MaskedTextBox maskedTextBox23;
        private MaskedTextBox maskedTextBox24;
        private Label label4;
        private Label label3;
        private Label label18;
    }
}
