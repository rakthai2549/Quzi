﻿namespace Quzi_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            maskedTextBox26.Text = "กันต์กวี หงษาวงศ์ ";
            maskedTextBox24.Text = "673450185-7 ";
            maskedTextBox22.Text = "CIS ";
            maskedTextBox20.Text = "แดง ";
            maskedTextBox25.Text = "สมหมาย แสงสี ";
            maskedTextBox23.Text = "673450123-4";
            maskedTextBox21.Text = "DS";
            maskedTextBox19.Text = "เขียว";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            maskedTextBox13.Text = "สมสี สีเรืองแสง ";
            maskedTextBox11.Text = "673450456-7 ";
            maskedTextBox15.Text = "CIS ";
            maskedTextBox14.Text = "ก้อง วัฒนชัย";
            maskedTextBox12.Text = "673450356-9 ";
            maskedTextBox16.Text = "CIS ";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Text = "673450987-6";
            maskedTextBox2.Text = "สมปอง แสงสม";
            maskedTextBox3.Text = "DS ";
            maskedTextBox4.Text = "90 ";
            maskedTextBox5.Text = "4 ";
            maskedTextBox6.Text = "673450987-6";
            maskedTextBox7.Text = "สมน้ำ หน้า";
            maskedTextBox8.Text = "cis ";
            maskedTextBox9.Text = "55 ";
            maskedTextBox10.Text = "1 ";

        }
    }
}
