﻿public class Student
{
    public string Name { get; set; }
    public string ID { get; set; }
    public string Major { get; set; }
    public int Grade { get; set; }
}
